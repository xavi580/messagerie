const express = require('express');
const http = require('http');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { Server } = require('socket.io');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me-in-production';
const TOKEN_TTL = '30d';

// ---------- Persistance (fichier JSON local) ----------
const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

let db = { users: [], conversations: [], messages: [] };

function saveDb() {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error('Erreur de sauvegarde DB :', err.message);
  }
}

try {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(DB_PATH)) {
    db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    db.users = db.users || [];
    db.conversations = db.conversations || [];
    db.messages = db.messages || [];
  } else {
    saveDb();
  }
} catch (err) {
  console.error('Échec du chargement DB :', err.message);
  db = { users: [], conversations: [], messages: [] };
}

// ---------- Middleware ----------
app.use(cors());
app.use(express.json());

function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    avatar: u.avatar || null,
    createdAt: u.createdAt,
    online: !!u.online
  };
}

function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Token manquant.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.users.find(u => u.id === payload.sub);
    if (!user) return res.status(401).json({ error: 'Utilisateur introuvable.' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Token invalide ou expiré.' });
  }
}

function signToken(user) {
  return jwt.sign({ sub: user.id, username: user.username }, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

// ---------- Authentification ----------
app.post('/api/auth/register', async (req, res) => {
  const { username, email, password } = req.body || {};
  const cleanUsername = (username || '').trim();
  const cleanEmail = (email || '').trim().toLowerCase();

  if (!cleanUsername || cleanUsername.length < 3)
    return res.status(400).json({ error: "Le nom d'utilisateur doit contenir au moins 3 caractères." });
  if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail))
    return res.status(400).json({ error: 'Adresse email invalide.' });
  if (!password || password.length < 6)
    return res.status(400).json({ error: 'Le mot de passe doit contenir au moins 6 caractères.' });
  if (db.users.some(u => u.email === cleanEmail))
    return res.status(409).json({ error: 'Un compte existe déjà avec cet email.' });
  if (db.users.some(u => u.username.toLowerCase() === cleanUsername.toLowerCase()))
    return res.status(409).json({ error: "Ce nom d'utilisateur est déjà pris." });

  const hash = await bcrypt.hash(password, 10);
  const user = {
    id: uuidv4(),
    username: cleanUsername,
    email: cleanEmail,
    passwordHash: hash,
    avatar: null,
    createdAt: new Date().toISOString(),
    online: false
  };
  db.users.push(user);
  saveDb();
  res.status(201).json({ token: signToken(user), user: publicUser(user) });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, username, password } = req.body || {};
  const identifier = ((email || username) || '').trim().toLowerCase();
  if (!identifier || !password)
    return res.status(400).json({ error: 'Identifiants manquants.' });
  const user = db.users.find(u => u.email.toLowerCase() === identifier || u.username.toLowerCase() === identifier);
  if (!user) return res.status(401).json({ error: 'Identifiants incorrects.' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Identifiants incorrects.' });
  res.json({ token: signToken(user), user: publicUser(user) });
});

app.get('/api/auth/me', authRequired, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

// ---------- Utilisateurs ----------
app.get('/api/users', authRequired, (req, res) => {
  const q = ((req.query.q || '') + '').trim().toLowerCase();
  let list = db.users.filter(u => u.id !== req.user.id);
  if (q) {
    list = list.filter(u =>
      u.username.toLowerCase().includes(q) || u.email.toLowerCase().includes(q)
    );
  }
  res.json({ users: list.map(publicUser).slice(0, 50) });
});

// ---------- Conversations ----------
function conversationFor(userId, otherId) {
  const members = [userId, otherId].sort();
  return db.conversations.find(c =>
    c.type === 'direct' &&
    c.members.length === 2 &&
    c.members[0] === members[0] &&
    c.members[1] === members[1]
  );
}

app.get('/api/conversations', authRequired, (req, res) => {
  const convos = db.conversations
    .filter(c => c.members.includes(req.user.id))
    .map(c => {
      const msgs = db.messages.filter(m => m.conversationId === c.id);
      return {
        id: c.id,
        type: c.type,
        name: c.name || null,
        members: c.members,
        participants: c.members.map(id => publicUser(db.users.find(u => u.id === id))).filter(Boolean),
        lastMessage: msgs.slice(-1)[0] || null,
        createdAt: c.createdAt
      };
    })
    .sort((a, b) => {
      const ta = a.lastMessage ? new Date(a.lastMessage.createdAt).getTime() : new Date(a.createdAt).getTime();
      const tb = b.lastMessage ? new Date(b.lastMessage.createdAt).getTime() : new Date(b.createdAt).getTime();
      return tb - ta;
    });
  res.json({ conversations: convos });
});

app.post('/api/conversations', authRequired, (req, res) => {
  const { userId } = req.body || {};
  const other = db.users.find(u => u.id === userId);
  if (!other) return res.status(404).json({ error: 'Utilisateur introuvable.' });
  let convo = conversationFor(req.user.id, other.id);
  if (!convo) {
    convo = {
      id: uuidv4(),
      type: 'direct',
      name: null,
      members: [req.user.id, other.id].sort(),
      createdAt: new Date().toISOString()
    };
    db.conversations.push(convo);
    saveDb();
  }
  const participants = convo.members.map(id => publicUser(db.users.find(u => u.id === id))).filter(Boolean);
  res.json({ conversation: convo, participants });
});

app.get('/api/conversations/:id/messages', authRequired, (req, res) => {
  const convo = db.conversations.find(c => c.id === req.params.id);
  if (!convo) return res.status(404).json({ error: 'Conversation introuvable.' });
  if (!convo.members.includes(req.user.id)) return res.status(403).json({ error: 'Accès refusé.' });
  res.json({ messages: db.messages.filter(m => m.conversationId === convo.id) });
});

// ---------- Santé ----------
app.get('/health', (req, res) => res.json({ ok: true, uptime: process.uptime() }));

// ---------- Socket.io ----------
const socketUser = new Map(); // socket.id -> user.id

io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  if (!token) return next(new Error('authentification requise'));
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.users.find(u => u.id === payload.sub);
    if (!user) return next(new Error('utilisateur introuvable'));
    socket.data.user = user;
    next();
  } catch (e) {
    return next(new Error('token invalide'));
  }
});

io.on('connection', (socket) => {
  const user = socket.data.user;
  user.online = true;
  socketUser.set(socket.id, user.id);
  socket.join(`user:${user.id}`);
  io.emit('presence', { userId: user.id, online: true });
  saveDb();

  socket.on('join:conversation', (conversationId) => {
    const convo = db.conversations.find(c => c.id === conversationId);
    if (convo && convo.members.includes(user.id)) {
      socket.join(`conversation:${conversationId}`);
    }
  });

  socket.on('message:send', (payload) => {
    const { conversationId, text } = payload || {};
    const clean = (text || '').trim();
    if (!clean) return;
    const convo = db.conversations.find(c => c.id === conversationId);
    if (!convo || !convo.members.includes(user.id)) return;
    const message = {
      id: uuidv4(),
      conversationId,
      senderId: user.id,
      text: clean.slice(0, 2000),
      createdAt: new Date().toISOString()
    };
    db.messages.push(message);
    saveDb();
    io.to(`conversation:${conversationId}`).emit('message:new', message);
  });

  socket.on('typing', ({ conversationId, isTyping }) => {
    const convo = db.conversations.find(c => c.id === conversationId);
    if (!convo) return;
    socket.to(`conversation:${conversationId}`).emit('typing', {
      conversationId,
      userId: user.id,
      isTyping: !!isTyping
    });
  });

  socket.on('disconnect', () => {
    socketUser.delete(socket.id);
    const stillConnected = [...socketUser.values()].filter(uid => uid === user.id).length > 0;
    if (!stillConnected) {
      user.online = false;
      io.emit('presence', { userId: user.id, online: false });
      saveDb();
    }
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Backend de chat démarré sur http://localhost:${PORT}`);
});
