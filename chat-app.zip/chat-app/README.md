# 💬 Messagerie temps réel — App complète

Application de messagerie texte multiplateforme : **backend** (API + temps réel) et **app mobile Flutter** (une seule base de code → **iOS + Android**).

## Architecture

```
chat-app/
├── backend/          # Node.js + Express + Socket.io + JWT
│   ├── server.js     # API REST + gestion temps réel
│   └── package.json
└── mobile/           # Flutter (Dart)
    ├── lib/
    │   ├── models/          # User, Message, Conversation
    │   ├── services/        # api_service.dart, socket_service.dart
    │   ├── providers/       # auth_provider, chat_provider (état)
    │   ├── screens/         # splash, login, register, home, chat, new convo
    │   └── utils/
    └── pubspec.yaml
```

## Fonctionnalités

- ✅ **Comptes utilisateurs** : inscription + connexion (JWT, mot de passe hashé avec bcrypt)
- ✅ **Messagerie en temps réel** : envoi/réception instantané via Socket.io
- ✅ **Statut de présence** : en ligne / hors ligne
- ✅ **Indication « X écrit… »**
- ✅ **Liste des conversations** avec dernier message
- ✅ **Recherche d'utilisateurs** pour démarrer une discussion
- ✅ Persistance des messages (JSON local côté serveur)
- ✅ Thème clair / sombre

## Démarrage

### 1. Backend

```bash
cd backend
npm install
npm start
```

Le serveur écoute sur `http://localhost:3000`.

### 2. App mobile (Flutter)

Prérequis : [Flutter SDK](https://docs.flutter.dev/get-started/install) installé.

```bash
cd mobile
flutter pub get
flutter run
```

> **Point important** : l'URL du backend est définie dans
> `mobile/lib/services/api_service.dart` (`baseUrl`).
> - Simulateur Android : `http://10.0.2.2:3000` (valeur par défaut)
> - Simulateur iOS : `http://localhost:3000`
> - Appareil physique : `http://<IP_LOCALE_DE_VOTRE_MACHINE>:3000`

## Tester en local

1. Lancez le backend.
2. Lancez l'app sur deux simulateurs / appareils.
3. Créez un compte sur chacun, recherchez l'autre utilisateur et discutez en temps réel.

## Prochaine étape (production)

Remplacer la persistance JSON par **MongoDB + Mongoose** ou **PostgreSQL**, définir un
`JWT_SECRET` robuste, utiliser HTTPS, et publier via les stores (Apple / Google Play).
