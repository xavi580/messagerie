import 'package:flutter/foundation.dart';

import '../models/conversation.dart';
import '../models/message.dart';
import '../models/user.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';

class ChatProvider extends ChangeNotifier {
  final ApiService _api = ApiService();
  final SocketService _socket = SocketService();

  List<Conversation> _conversations = [];
  final Map<String, List<Message>> _messagesByConvo = {};
  final Map<String, bool> _presence = {};
  final Map<String, String> _typing = {}; // conversationId -> username

  bool _loadingConversations = false;
  String? _error;

  List<Conversation> get conversations => _conversations;
  bool get loadingConversations => _loadingConversations;
  String? get error => _error;

  void bind(String token) {
    _api.setToken(token);
    _socket
      ..onMessage = _handleIncomingMessage
      ..onPresence = _handlePresence
      ..onTyping = _handleTyping;
    _socket.connect(token);
  }

  void unbind() {
    _socket.onMessage = null;
    _socket.onPresence = null;
    _socket.onTyping = null;
    _socket.disconnect();
  }

  // ---------- Utilisateurs ----------
  Future<List<User>> searchUsers(String query) async {
    try {
      return await _api.searchUsers(query);
    } on Exception catch (e) {
      _error = e.toString();
      notifyListeners();
      return [];
    }
  }

  // ---------- Conversations ----------
  Future<void> loadConversations() async {
    _loadingConversations = true;
    _error = null;
    notifyListeners();
    try {
      _conversations = await _api.getConversations();
    } on Exception catch (e) {
      _error = e.toString();
    } finally {
      _loadingConversations = false;
      notifyListeners();
    }
  }

  Future<Conversation?> openConversation(String userId) async {
    try {
      final convo = await _api.openConversation(userId);
      _conversations = [
        convo,
        ..._conversations.where((c) => c.id != convo.id),
      ];
      notifyListeners();
      return convo;
    } on Exception catch (e) {
      _error = e.toString();
      notifyListeners();
      return null;
    }
  }

  List<Message> messagesFor(String conversationId) =>
      _messagesByConvo[conversationId] ?? [];

  Future<void> loadMessages(String conversationId) async {
    try {
      final msgs = await _api.getMessages(conversationId);
      _messagesByConvo[conversationId] = msgs;
      notifyListeners();
    } on Exception catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  void joinConversation(String conversationId) {
    _socket.joinConversation(conversationId);
  }

  void sendMessage(String conversationId, String text) {
    _socket.sendMessage(conversationId, text);
  }

  void sendTyping(String conversationId, bool isTyping) {
    _socket.sendTyping(conversationId, isTyping);
  }

  bool isOnline(String userId) => _presence[userId] ?? false;
  String? typingUserFor(String conversationId) => _typing[conversationId];

  // ---------- Handlers Socket ----------
  void _handleIncomingMessage(Message message) {
    final list = _messagesByConvo.putIfAbsent(message.conversationId, () => []);
    if (!list.any((m) => m.id == message.id)) {
      list.add(message);
    }
    _typing.remove(message.conversationId);

    // Mettre à jour le dernier message de la conversation.
    final idx = _conversations.indexWhere((c) => c.id == message.conversationId);
    if (idx >= 0) {
      // Reconstruire l'objet avec le nouveau dernier message (immutabilité).
      final old = _conversations[idx];
      _conversations[idx] = Conversation(
        id: old.id,
        type: old.type,
        name: old.name,
        members: old.members,
        participants: old.participants,
        lastMessage: message,
        createdAt: old.createdAt,
      );
      final moved = _conversations.removeAt(idx);
      _conversations.insert(0, moved);
    }
    notifyListeners();
  }

  void _handlePresence(String userId, bool online) {
    _presence[userId] = online;
    notifyListeners();
  }

  void _handleTyping(String conversationId, String userId, bool isTyping) {
    final convo = _conversations.where((c) => c.id == conversationId);
    if (convo.isEmpty) return;
    final user = convo.first.participants.where((p) => p.id == userId);
    if (user.isEmpty) return;
    if (isTyping) {
      _typing[conversationId] = user.first.username;
    } else {
      _typing.remove(conversationId);
    }
    notifyListeners();
  }
}
