import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  final ApiService _api = ApiService();
  User? _user;
  String? _token;

  bool _loading = true;
  bool _authBusy = false;
  String? _error;

  User? get user => _user;
  String? get token => _token;
  bool get loading => _loading;
  bool get authBusy => _authBusy;
  String? get error => _error;
  bool get isAuthenticated => _user != null && _token != null;

  static const _prefs = SharedPreferences.getInstance;

  Future<void> bootstrap() async {
    try {
      final prefs = await _prefs;
      final storedToken = prefs.getString('auth_token');
      if (storedToken != null) {
        _api.setToken(storedToken);
        final me = await _api.me();
        _user = me;
        _token = storedToken;
      }
    } catch (_) {
      await _logout();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<bool> login(String identifier, String password) async {
    _error = null;
    _authBusy = true;
    notifyListeners();
    try {
      final result = await _api.login(identifier: identifier, password: password);
      await _persist(result.token, result.user);
      return true;
    } on Exception catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _authBusy = false;
      notifyListeners();
    }
  }

  Future<bool> register({
    required String username,
    required String email,
    required String password,
  }) async {
    _error = null;
    _authBusy = true;
    notifyListeners();
    try {
      final result = await _api.register(
        username: username,
        email: email,
        password: password,
      );
      await _persist(result.token, result.user);
      return true;
    } on Exception catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _authBusy = false;
      notifyListeners();
    }
  }

  Future<void> _persist(String token, User user) async {
    _token = token;
    _user = user;
    _api.setToken(token);
    final prefs = await _prefs;
    await prefs.setString('auth_token', token);
  }

  Future<void> logout() async {
    await _logout();
  }

  Future<void> _logout() async {
    _user = null;
    _token = null;
    _api.setToken(null);
    final prefs = await _prefs;
    await prefs.remove('auth_token');
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
