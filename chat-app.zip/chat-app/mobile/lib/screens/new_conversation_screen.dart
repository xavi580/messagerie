import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/user.dart';
import '../providers/auth_provider.dart';
import '../providers/chat_provider.dart';
import 'chat_screen.dart';

class NewConversationScreen extends StatefulWidget {
  const NewConversationScreen({super.key});

  @override
  State<NewConversationScreen> createState() => _NewConversationScreenState();
}

class _NewConversationScreenState extends State<NewConversationScreen> {
  final _controller = TextEditingController();
  List<User> _results = [];
  bool _loading = false;
  bool _searched = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _search([String? query]) async {
    final chat = context.read<ChatProvider>();
    setState(() {
      _loading = true;
      _searched = true;
    });
    final results = await chat.searchUsers(query ?? _controller.text);
    if (!mounted) return;
    setState(() {
      _results = results;
      _loading = false;
    });
  }

  Future<void> _open(User user) async {
    final chat = context.read<ChatProvider>();
    final convo = await chat.openConversation(user.id);
    if (!mounted || convo == null) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => ChatScreen(conversation: convo)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    final me = context.watch<AuthProvider>().user;

    return Scaffold(
      appBar: AppBar(title: const Text('Nouvelle discussion')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _controller,
              autofocus: true,
              decoration: InputDecoration(
                labelText: 'Rechercher un utilisateur',
                prefixIcon: const Icon(Icons.search),
                border: const OutlineInputBorder(),
                suffixIcon: _controller.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _controller.clear();
                          setState(() {});
                        },
                      )
                    : null,
              ),
              onChanged: (_) => setState(() {}),
              onSubmitted: _search,
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _results.isEmpty
                    ? Center(
                        child: Text(
                          _searched ? 'Aucun utilisateur trouvé' : 'Cherchez un utilisateur',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      )
                    : ListView.separated(
                        itemCount: _results.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          final u = _results[index];
                          return ListTile(
                            leading: CircleAvatar(
                              backgroundColor: const Color(0xFF6C5CE7),
                              child: Text(
                                u.initials,
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                            title: Text(u.username),
                            subtitle: Text(u.email),
                            trailing: chat.isOnline(u.id)
                                ? _OnlineBadge()
                                : const SizedBox.shrink(),
                            onTap: () => _open(u),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _OnlineBadge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.circle, color: Colors.green, size: 10),
        const SizedBox(width: 4),
        Text('En ligne', style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}
