import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/conversation.dart';
import '../../models/user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../utils/format.dart';
import '../chat_screen.dart';
import '../new_conversation_screen.dart';

class ConversationsScreen extends StatelessWidget {
  const ConversationsScreen({super.key});

  User? _other(BuildContext context, Conversation c) {
    final me = context.read<AuthProvider>().user;
    if (me == null) return null;
    return c.participants.where((p) => p.id != me.id).toList().isNotEmpty
        ? c.participants.firstWhere((p) => p.id != me.id)
        : (c.participants.isNotEmpty ? c.participants.first : null);
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();

    if (chat.conversations.isEmpty && !chat.loadingConversations) {
      return _EmptyState(
        onNewChat: () => _openNewConversation(context),
        onRefresh: () => chat.loadConversations(),
      );
    }

    return ListView.separated(
      itemCount: chat.conversations.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, index) {
        final convo = chat.conversations[index];
        final other = _other(context, convo);
        final online = other != null && chat.isOnline(other.id);
        final sub = convo.lastMessage?.text ?? 'Démarrer une discussion';
        return ListTile(
          leading: _Avatar(
            initials: other?.initials ?? '?',
            online: online,
          ),
          title: Text(
            other?.username ?? convo.name ?? 'Conversation',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          subtitle: Text(
            sub,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: convo.lastMessage != null
              ? Text(
                  shortDate(convo.lastMessage!.createdAt),
                  style: Theme.of(context).textTheme.bodySmall,
                )
              : null,
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => ChatScreen(conversation: convo),
            ),
          ),
        );
      },
    );
  }

  void _openNewConversation(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NewConversationScreen()),
    );
  }
}

class _Avatar extends StatelessWidget {
  final String initials;
  final bool online;

  const _Avatar({required this.initials, this.online = false});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        CircleAvatar(
          radius: 24,
          backgroundColor: const Color(0xFF6C5CE7),
          child: Text(
            initials,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
        if (online)
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              width: 13,
              height: 13,
              decoration: BoxDecoration(
                color: Colors.green,
                shape: BoxShape.circle,
                border: Border.all(color: Theme.of(context).scaffoldBackgroundColor, width: 2),
              ),
            ),
          ),
      ],
    );
  }
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onNewChat;
  final VoidCallback onRefresh;

  const _EmptyState({required this.onNewChat, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.forum_outlined, size: 64, color: Colors.grey),
          const SizedBox(height: 16),
          const Text('Aucune conversation'),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: onNewChat,
            icon: const Icon(Icons.add),
            label: const Text('Nouvelle conversation'),
          ),
        ],
      ),
    );
  }
}
