import 'package:socket_io_client/socket_io_client.dart' as io;

import '../models/message.dart';
import 'api_service.dart';

typedef MessageCallback = void Function(Message message);
typedef PresenceCallback = void Function(String userId, bool online);
typedef TypingCallback = void Function(String conversationId, String userId, bool isTyping);

class SocketService {
  io.Socket? _socket;

  MessageCallback? onMessage;
  PresenceCallback? onPresence;
  TypingCallback? onTyping;

  bool get connected => _socket?.connected ?? false;

  void connect(String token) {
    disconnect();
    _socket = io.io(
      ApiService.baseUrl,
      io.OptionBuilder()
          .setTransports(['websocket'])
          .setAuth({'token': token})
          .disableAutoConnect()
          .build(),
    );

    _socket!
      ..onConnect((_) {})
      ..on('message:new', (data) {
        if (data is Map && onMessage != null) {
          onMessage!(Message.fromJson(Map<String, dynamic>.from(data)));
        }
      })
      ..on('presence', (data) {
        if (data is Map && onPresence != null) {
          final userId = data['userId'] as String?;
          final online = data['online'] == true;
          if (userId != null) onPresence!(userId, online);
        }
      })
      ..on('typing', (data) {
        if (data is Map && onTyping != null) {
          final conversationId = data['conversationId'] as String?;
          final userId = data['userId'] as String?;
          final isTyping = data['isTyping'] == true;
          if (conversationId != null && userId != null) {
            onTyping!(conversationId, userId, isTyping);
          }
        }
      })
      ..connect();
  }

  void joinConversation(String conversationId) {
    _socket?.emit('join:conversation', conversationId);
  }

  void sendMessage(String conversationId, String text) {
    _socket?.emit('message:send', {
      'conversationId': conversationId,
      'text': text,
    });
  }

  void sendTyping(String conversationId, bool isTyping) {
    _socket?.emit('typing', {
      'conversationId': conversationId,
      'isTyping': isTyping,
    });
  }

  void disconnect() {
    _socket?.dispose();
    _socket = null;
  }
}
