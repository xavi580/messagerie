import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/conversation.dart';
import '../models/message.dart';
import '../models/user.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class ApiService {
  // Base du backend. Sur simulateur Android : http://10.0.2.2:3000
  // Sur appareil physique : remplacez par l'IP locale de votre machine.
  static String baseUrl = 'http://10.0.2.2:3000';

  String? _token;
  void setToken(String? token) => _token = token;
  String get _authToken => _token ?? '';

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  // ---------- Auth ----------
  Future<({String token, User user})> register({
    required String username,
    required String email,
    required String password,
  }) async {
    final res = await http
        .post(
          Uri.parse('$baseUrl/api/auth/register'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'username': username, 'email': email, 'password': password}),
        )
        .timeout(const Duration(seconds: 15));
    return _parseAuth(res);
  }

  Future<({String token, User user})> login({
    required String identifier,
    required String password,
  }) async {
    final res = await http
        .post(
          Uri.parse('$baseUrl/api/auth/login'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'email': identifier, 'password': password}),
        )
        .timeout(const Duration(seconds: 15));
    return _parseAuth(res);
  }

  ({String token, User user}) _parseAuth(http.Response res) {
    final body = _decode(res);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      return (
        token: body['token'] as String,
        user: User.fromJson(body['user'] as Map<String, dynamic>),
      );
    }
    throw ApiException(body['error'] as String? ?? 'Erreur inconnue');
  }

  Future<User> me() async {
    final res = await http.get(
      Uri.parse('$baseUrl/api/auth/me'),
      headers: _headers,
    );
    final body = _decode(res);
    if (res.statusCode == 200) {
      return User.fromJson(body['user'] as Map<String, dynamic>);
    }
    throw ApiException(body['error'] as String? ?? 'Erreur inconnue');
  }

  // ---------- Utilisateurs ----------
  Future<List<User>> searchUsers(String query) async {
    final uri = Uri.parse('$baseUrl/api/users').replace(queryParameters: {
      if (query.trim().isNotEmpty) 'q': query.trim(),
    });
    final res = await http.get(uri, headers: _headers);
    final body = _decode(res);
    if (res.statusCode == 200) {
      return (body['users'] as List? ?? [])
          .map((e) => User.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    throw ApiException(body['error'] as String? ?? 'Erreur inconnue');
  }

  // ---------- Conversations ----------
  Future<List<Conversation>> getConversations() async {
    final res = await http.get(
      Uri.parse('$baseUrl/api/conversations'),
      headers: _headers,
    );
    final body = _decode(res);
    if (res.statusCode == 200) {
      return (body['conversations'] as List? ?? [])
          .map((e) => Conversation.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    throw ApiException(body['error'] as String? ?? 'Erreur inconnue');
  }

  Future<Conversation> openConversation(String userId) async {
    final res = await http.post(
      Uri.parse('$baseUrl/api/conversations'),
      headers: _headers,
      body: jsonEncode({'userId': userId}),
    );
    final body = _decode(res);
    if (res.statusCode == 200) {
      return Conversation.fromJson({
        ...body['conversation'] as Map<String, dynamic>,
        'participants': body['participants'],
      });
    }
    throw ApiException(body['error'] as String? ?? 'Erreur inconnue');
  }

  Future<List<Message>> getMessages(String conversationId) async {
    final res = await http.get(
      Uri.parse('$baseUrl/api/conversations/$conversationId/messages'),
      headers: _headers,
    );
    final body = _decode(res);
    if (res.statusCode == 200) {
      return (body['messages'] as List? ?? [])
          .map((e) => Message.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    throw ApiException(body['error'] as String? ?? 'Erreur inconnue');
  }

  Map<String, dynamic> _decode(http.Response res) {
    try {
      return jsonDecode(res.body) as Map<String, dynamic>;
    } catch (_) {
      return {'error': 'Réponse invalide du serveur (code ${res.statusCode})'};
    }
  }
}
