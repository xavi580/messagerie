class User {
  final String id;
  final String username;
  final String email;
  final String? avatar;
  final DateTime? createdAt;
  final bool online;

  const User({
    required this.id,
    required this.username,
    required this.email,
    this.avatar,
    this.createdAt,
    this.online = false,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as String,
      username: json['username'] as String,
      email: json['email'] as String,
      avatar: json['avatar'] as String?,
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'] as String)
          : null,
      online: json['online'] == true,
    );
  }

  String get initials {
    final parts = username.trim().split(RegExp(r'\s+'));
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return username.isEmpty ? '?' : username[0].toUpperCase();
  }
}
