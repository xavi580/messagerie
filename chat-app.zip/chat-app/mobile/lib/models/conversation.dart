import 'message.dart';
import 'user.dart';

class Conversation {
  final String id;
  final String type;
  final String? name;
  final List<String> members;
  final List<User> participants;
  final Message? lastMessage;
  final DateTime createdAt;

  const Conversation({
    required this.id,
    required this.type,
    this.name,
    required this.members,
    required this.participants,
    this.lastMessage,
    required this.createdAt,
  });

  factory Conversation.fromJson(Map<String, dynamic> json) {
    return Conversation(
      id: json['id'] as String,
      type: json['type'] as String,
      name: json['name'] as String?,
      members: List<String>.from(json['members'] as List? ?? []),
      participants: (json['participants'] as List? ?? [])
          .map((e) => User.fromJson(e as Map<String, dynamic>))
          .toList(),
      lastMessage: json['lastMessage'] != null
          ? Message.fromJson(json['lastMessage'] as Map<String, dynamic>)
          : null,
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
          DateTime.now(),
    );
  }
}
