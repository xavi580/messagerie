import 'package:intl/intl.dart';

String timeOfDay(DateTime dt) => DateFormat.Hm().format(dt.toLocal());

String shortDate(DateTime dt) {
  final local = dt.toLocal();
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final that = DateTime(local.year, local.month, local.day);
  final diff = today.difference(that).inDays;

  if (diff == 0) return timeOfDay(local);
  if (diff == 1) return 'Hier';
  if (diff < 7) return DateFormat.E().format(local);
  return DateFormat('dd/MM/yy').format(local);
}

String messageTime(DateTime dt) => DateFormat.Hm().format(dt.toLocal());
